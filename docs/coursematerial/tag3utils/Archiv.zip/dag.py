"""Einfacher Airflow-DAG fuer einen taeglichen Spark-Job auf Cloudera."""

from datetime import datetime, timedelta

from airflow import DAG
from cloudera.cdp.airflow.operators.cde_operator import CDEJobRunOperator

default_args = {
    "owner": "datamesh",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


dag = DAG(
    dag_id="datamesh_spark_table_transfer_daily",
    default_args=default_args,
    description="Liest taeglich eine Tabelle und schreibt sie in eine andere Tabelle",
    start_date=datetime(2026, 6, 23),
    schedule="@daily",  # einmal pro Tag
    catchup=False,
    tags=["spark", "cloudera", "datamesh"],
)

cde_job_staging = CDEJobRunOperator(
    task_id="spark_table_transfer_staging",
    job_name="Spark_incremental_staging",
    dag=dag,
)

cde_job_audit = CDEJobRunOperator(
    task_id="spark_table_transfer_audit",
    job_name="Spark_incremental_audit",
    dag=dag,
)

cde_job_publish = CDEJobRunOperator(
    task_id="spark_table_transfer_publish",
    job_name="Spark_incremental_publish",
    dag=dag,
)

cde_job_staging >> cde_job_audit
cde_job_audit >> cde_job_publish
