from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from sql_statements import (
    DEFAULT_DATABASE,
    AUDIT_TABLE_INCREMENTAL,
    SOURCE_TABLE_INCREMENTAL,
    TARGET_TABLE_INCREMENTAL,
    use_database_statement,
    get_latest_incremental,
    create_audit_table_statement,
    insert_audit_record_statement,
)

# --- Configuration ---
INCREMENT_COL = "updated_at"

print(f"--- Starting CDE Audit Job: DB={DEFAULT_DATABASE} | Source={SOURCE_TABLE_INCREMENTAL} | Dest={AUDIT_TABLE_INCREMENTAL} ---")

# --- Initialize Spark Session ---
spark = SparkSession \
    .builder \
    .appName("Pyspark Iceberg Audit Job") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
spark.sql(use_database_statement(DEFAULT_DATABASE))

print(f"\n--- Reading Latest Timestamp from Target Table: {TARGET_TABLE_INCREMENTAL} ---")
latest_timestamp = spark.sql(get_latest_incremental(TARGET_TABLE_INCREMENTAL, INCREMENT_COL)).first()[0]
if latest_timestamp is None:
    print(f"  -> No records found in {TARGET_TABLE_INCREMENTAL}. Using default timestamp for audit.")
    latest_timestamp = "1970-01-01 00:00:00"

rows_loaded = spark.table(TARGET_TABLE_INCREMENTAL).count()

print(f"\n--- Writing Audit Record to {AUDIT_TABLE_INCREMENTAL} ---")
spark.sql(
    insert_audit_record_statement(
        AUDIT_TABLE_INCREMENTAL,
        SOURCE_TABLE_INCREMENTAL,
        TARGET_TABLE_INCREMENTAL,
        latest_timestamp,
        rows_loaded,
    )
)

print("\n--- SUCCESS: Audit Job Finished ---")
spark.stop()