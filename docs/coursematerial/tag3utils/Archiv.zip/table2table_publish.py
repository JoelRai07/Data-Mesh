from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from sql_statements import (
    DEFAULT_DATABASE,
    PUBLISH_TABLE_INCREMENTAL,
    TARGET_TABLE_INCREMENTAL,
    use_database_statement,
    create_table_statement,
    publish_table_statement,
)

# --- Configuration ---

print(f"--- Starting CDE Publish Job: DB={DEFAULT_DATABASE} | Source={TARGET_TABLE_INCREMENTAL} | Dest={PUBLISH_TABLE_INCREMENTAL} ---")

# --- Initialize Spark Session ---
spark = SparkSession \
    .builder \
    .appName("Pyspark Iceberg Publish Job") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
spark.sql(use_database_statement(DEFAULT_DATABASE))

print(f"\n--- Publishing Results to {PUBLISH_TABLE_INCREMENTAL} ---")
spark.sql(publish_table_statement(TARGET_TABLE_INCREMENTAL, PUBLISH_TABLE_INCREMENTAL))

print("\n--- SUCCESS: Publish Job Finished ---")
spark.stop()