from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from sql_statements import DEFAULT_DATABASE, SOURCE_TABLE_FULL, TARGET_TABLE

# --- Configuration ---
# Using the external tables as requested

print(f"--- Starting CDE External Job: DB={DEFAULT_DATABASE} | Dest={TARGET_TABLE} ---")

# --- Initialize Spark Session ---
spark = SparkSession \
    .builder \
    .appName("Pyspark Iceberg Table2Table") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
spark.sql(f"use {DEFAULT_DATABASE}")

# --- Core Logic using External Tables ---
sql_query = f"""
SELECT *
FROM {SOURCE_TABLE_FULL}
"""

print("\n--- Executing Transformation on External Tables ---")
dispatch_data = spark.sql(sql_query)

# --- Preview (Helpful for debugging in CDE Job Logs) ---
dispatch_data.show(10)

# --- Write to Hive ---
print(f"\n--- Saving Results to {TARGET_TABLE} ---")
dispatch_data.writeTo(TARGET_TABLE).overwritePartitions()

print("\n--- SUCCESS: Job Finished ---")
spark.stop()