from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from sql_statements import (
    DEFAULT_DATABASE,
    SOURCE_TABLE_INCREMENTAL,
    TARGET_TABLE_INCREMENTAL,
    use_database_statement,
    select_source_data_statement,
    get_latest_incremental,
    create_table_statement,
)

# --- Configuration ---
# tables used
INCREMENT_COL = "updated_at"

print(f"--- Starting CDE External Job: DB={DEFAULT_DATABASE} | Dest={TARGET_TABLE_INCREMENTAL} ---")

# --- Initialize Spark Session ---
spark = SparkSession \
    .builder \
    .appName("Pyspark Iceberg Table2Table") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
spark.sql(use_database_statement(DEFAULT_DATABASE))

print(f"\n--- Reading Latest Timestamp from Target Table: {TARGET_TABLE_INCREMENTAL} ---")
latest_timestamp = spark.sql(get_latest_incremental(TARGET_TABLE_INCREMENTAL, INCREMENT_COL)).first()[0]
if latest_timestamp is None:
    print(f"  -> No records found in {TARGET_TABLE_INCREMENTAL}. Performing full load.")
    latest_timestamp = "1970-01-01 00:00:00"  # Default timestamp for full load
    
print("\n--- Executing Transformation on External Tables ---")
dispatch_data = spark.sql(select_source_data_statement(SOURCE_TABLE_INCREMENTAL, INCREMENT_COL, latest_timestamp)).cache()
rows_loaded = dispatch_data.count()

# --- Preview (Helpful for debugging in CDE Job Logs) ---
dispatch_data.show(10)

# --- Write to Iceberg Table ---
print(f"\n--- Saving Results to {TARGET_TABLE_INCREMENTAL} ---")
dispatch_data.writeTo(TARGET_TABLE_INCREMENTAL).append()

print("\n--- SUCCESS: Job Finished ---")
spark.stop()