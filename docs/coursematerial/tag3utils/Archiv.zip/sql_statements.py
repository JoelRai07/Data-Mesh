DEFAULT_DATABASE = "default"

SOURCE_TABLE_FULL = "spark_source_orders"
SOURCE_TABLE_INCREMENTAL = "spark_source_orders_incremental"
TARGET_TABLE = "spark_target_orders_v2"
TARGET_TABLE_INCREMENTAL = "spark_target_orders_incremental"
AUDIT_TABLE_INCREMENTAL = "spark_target_orders_incremental_audit"
PUBLISH_TABLE_INCREMENTAL = "spark_target_orders_incremental_publish"


def use_database_statement(db: str) -> str:
    return f"USE {db}"


def drop_table_statement(table: str) -> str:
    return f"DROP TABLE IF EXISTS {table}"


def create_table_statement(table: str) -> str:
    return f"""
CREATE TABLE IF NOT EXISTS {table} (
    incremental_id BIGINT,
    customer_name  STRING,
    city           STRING,
    product_name   STRING,
    quantity       INT,
    amount         DECIMAL(10,2),
    updated_at     TIMESTAMP
)
STORED AS ICEBERG
"""


def create_audit_table_statement(table: str) -> str:
    return f"""
CREATE TABLE IF NOT EXISTS {table} (
	audit_ts TIMESTAMP,
	source_table STRING,
	target_table STRING,
	latest_timestamp TIMESTAMP,
	rows_loaded BIGINT
)
STORED AS ICEBERG
"""


def seed_source_table_statement(table: str) -> str:
    return f"""
INSERT INTO {table}
SELECT 1, 'Mia Weber', 'Stuttgart', 'Sensor Kit', 2, CAST(149.90 AS DECIMAL(10,2)), CAST('2026-06-17 08:15:00' AS TIMESTAMP)
UNION ALL
SELECT 2, 'Leon Becker', 'Karlsruhe', 'Gateway Hub', 1, CAST(249.00 AS DECIMAL(10,2)), CAST('2026-06-17 08:30:00' AS TIMESTAMP)
UNION ALL
SELECT 3, 'Sofia Klein', 'Mannheim', 'Edge Node', 4, CAST(89.50 AS DECIMAL(10,2)), CAST('2026-06-17 09:10:00' AS TIMESTAMP)
UNION ALL
SELECT 4, 'Noah Fischer', 'Heilbronn', 'Telemetry Pack', 3, CAST(59.99 AS DECIMAL(10,2)), CAST('2026-06-17 09:45:00' AS TIMESTAMP)
UNION ALL
SELECT 5, 'Emma Wolf', 'Freiburg', 'IoT Bridge', 1, CAST(319.00 AS DECIMAL(10,2)), CAST('2026-06-17 10:05:00' AS TIMESTAMP)
"""

def select_preview_statement(table: str, limit: int = 10) -> str:
    return f"SELECT * FROM {table} LIMIT {limit}"


def get_latest_incremental(target_table: str, timestamp_column: str) -> str:
    return f"SELECT max({timestamp_column}) as latest_timestamp FROM {target_table}"

def select_source_data_statement(source_table: str, increment_column: str, latest_timestamp) -> str:
    return f"""
SELECT *
FROM {source_table}
WHERE {increment_column} > CAST('{latest_timestamp}' AS TIMESTAMP)
"""


def insert_audit_record_statement(audit_table: str, source_table: str, target_table: str, latest_timestamp, rows_loaded: int) -> str:
    return f"""
INSERT INTO {audit_table}
SELECT
	current_timestamp(),
	'{source_table}',
	'{target_table}',
	CAST('{latest_timestamp}' AS TIMESTAMP),
	CAST({rows_loaded} AS BIGINT)
"""


def publish_table_statement(source_table: str, publish_table: str) -> str:
    return f"""
INSERT OVERWRITE TABLE {publish_table}
SELECT *
FROM {source_table}
"""