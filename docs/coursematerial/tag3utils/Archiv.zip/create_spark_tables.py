import os
from impala.dbapi import connect
from dotenv import load_dotenv
from sql_statements import (
    SOURCE_TABLE_FULL,
    SOURCE_TABLE_INCREMENTAL,
    TARGET_TABLE,
    TARGET_TABLE_INCREMENTAL,
    AUDIT_TABLE_INCREMENTAL,
    PUBLISH_TABLE_INCREMENTAL,
    drop_table_statement,
    create_table_statement,
    create_audit_table_statement,
    seed_source_table_statement,
    select_preview_statement
)

load_dotenv()

connection = connect(
    host=os.getenv("IMPALA_HOST"),
    port=int(os.getenv("IMPALA_PORT")),
    auth_mechanism="LDAP",
    use_ssl=True,
    use_http_transport=True,
    http_path=os.getenv("IMPALA_HTTP_PATH"),
    user=os.getenv("IMPALA_USER"),
    password=os.getenv("IMPALA_PASSWORD"),
)

cursor = connection.cursor()

all_tables = [
    SOURCE_TABLE_FULL,
    SOURCE_TABLE_INCREMENTAL,
    TARGET_TABLE,
    TARGET_TABLE_INCREMENTAL,
    PUBLISH_TABLE_INCREMENTAL,
]

audit_tables = [AUDIT_TABLE_INCREMENTAL]

source_tables = [SOURCE_TABLE_FULL, SOURCE_TABLE_INCREMENTAL]

for table in all_tables:
    print(f"Loesche und erstelle Tabelle: {table} ...")
    cursor.execute(drop_table_statement(table))
    cursor.execute(create_table_statement(table))
    print("  -> OK")

for table in audit_tables:
    print(f"Loesche und erstelle Audit-Tabelle: {table} ...")
    cursor.execute(drop_table_statement(table))
    cursor.execute(create_audit_table_statement(table))
    print("  -> OK")
    
for table in source_tables:
    print(f"Befülle Quelltabelle: {table} ...")
    cursor.execute(seed_source_table_statement(table))
    print("  -> OK")
    
cursor.execute("INVALIDATE METADATA")
print("Metadaten aktualisiert.")

for table_name in all_tables:
    print(f"\nSELECT * FROM {table_name} LIMIT 10:")
    cursor.execute(select_preview_statement(table_name))
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            print(row)
    else:
        print("(keine Ergebnisse)")

cursor.close()
connection.close()

